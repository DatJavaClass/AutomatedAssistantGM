/* "Open AAGM-G Chat" macro source, stringified. */

async function chatBoxMain() {
  const MODULE_ID = 'aagm-g';
  const STYLE_ID = 'aagmg-chat-theme';
  const LAYOUT_ID = 'aagmg-chat-layout';
  const L = (k) => game.i18n.localize('AAGM_G.CHAT.' + k);
  const TABS_ON = game.settings.get(MODULE_ID, 'multitasking');
  const MAIN_TAB = 't-main', TAB_MAX = 5, TAB_TITLE_LEN = 24;

  /* Prefer journal styles over fallback CSS. */
  async function injectMacroStyles(styleId, pageName, fallbackCSS) {
    if (document.getElementById(styleId)) return; /* style present returns, else injects */
    let css = fallbackCSS || '';
    try {
      const journal = game.journal.getName('VTT Macro Styles');
      const page = journal?.pages?.getName(pageName);
      if (page) { /* page found reads css, else fallback */
        const div = document.createElement('div');
        div.innerHTML = page.text?.content || '';
        const raw = div.textContent?.trim();
        if (raw) css = raw; /* text found overrides fallback css */
      }
    } catch { /* fallback silently takes over */ }
    if (!css) return; /* no css returns, else appends style */
    const style = document.createElement('style');
    style.id = styleId;
    style.textContent = css;
    document.head.appendChild(style);
  }

  /* Provide a minimal dark fallback. */
  const FALLBACK_CSS = `
    .forge-dialog-dark { background:#1a1a1a; color:#e0e0e0; }
    .forge-dialog-dark .section { background:#2a2a2a; border:1px solid #00ffcc; padding:8px; border-radius:4px; }
    .forge-dialog-dark label, .forge-dialog-dark .section-title { color:#00ffcc; }
    .forge-dialog-dark .warning { color:#ffaa00; }
  `;

  await injectMacroStyles(STYLE_ID, 'Dark Theme', FALLBACK_CSS);

  /* Apply the chat layout. */
  if (!document.getElementById(LAYOUT_ID)) { /* layout missing injects style, else skipped */
    const s = document.createElement('style');
    s.id = LAYOUT_ID;
    /* Fixed height prevents Foundry flex collapse. */
    s.textContent = `
      .aagmg-wrap { display:flex; flex-direction:column; gap:8px; }
      .aagmg-status { font-size:12px; padding:5px 8px; border-radius:3px; border:1px solid #00ffcc; }
      .aagmg-status.ready { color:#00ffcc; border-color:#00ffcc; }
      .aagmg-status.warn  { color:#ffaa00; border-color:#ffaa00; }
      .aagmg-tabs { display:flex; align-items:stretch; gap:2px; min-height:28px; overflow-x:auto; }
      .aagmg-tab { width:auto; height:auto; line-height:1.2; flex:1 1 0; min-width:0; display:flex;
                   align-items:center; gap:4px; padding:4px 6px; background:#222; color:#bbb;
                   border:1px solid #444; border-bottom:none; border-radius:4px 4px 0 0; cursor:pointer; }
      .aagmg-tab.aagmg-active { background:#141414; color:#fff; border-color:#00ffcc; }
      .aagmg-tab::before { content:''; flex:none; width:6px; height:6px; border-radius:50%; background:#777; }
      .aagmg-tab.aagmg-working::before { background:#00ffcc; }
      .aagmg-tab.aagmg-done::before { background:#66cc66; }
      .aagmg-tab-t { flex:1 1 auto; min-width:0; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
      .aagmg-tab-x { opacity:0.6; padding:0 2px; flex:none; }
      .aagmg-tab-x:hover { opacity:1; color:#ff6666; }
      .aagmg-tab-add { width:auto; height:auto; line-height:1.2; flex:none; padding:4px 9px;
                       background:#222; border:1px solid #444; border-bottom:none;
                       border-radius:4px 4px 0 0; color:#00ffcc; cursor:pointer; font-weight:600; }
      .aagmg-tab-add:disabled { opacity:0.35; cursor:default; }
      .aagmg-log { height:320px; width:100%; box-sizing:border-box; overflow-y:auto;
                 background:#141414; border:1px solid #333; border-radius:4px; padding:8px;
                 display:flex; flex-direction:column; gap:6px; }
      .aagmg-log[hidden] { display:none; }
      .aagmg-msg { white-space:pre-wrap; word-break:break-word; padding:6px 8px;
                 border-radius:6px; font-size:13px; line-height:1.4; }
      .aagmg-msg .aagmg-who { display:block; font-size:11px; opacity:0.75; margin-bottom:2px; }
      .aagmg-user { background:#22323a; border-left:3px solid #00ffcc; align-self:flex-end; max-width:85%; }
      .aagmg-assistant { background:#2a2a2a; border-left:3px solid #ffaa00; align-self:flex-start; max-width:85%; }
      .aagmg-sys { color:#ffaa00; font-size:12px; align-self:center; }
      .aagmg-input { display:block; width:100% !important; box-sizing:border-box !important;
                   height:96px; resize:vertical; color:#fff !important; background:#101010;
                   border:1px solid #00ffcc; border-radius:4px; padding:8px;
                   font-family:inherit; font-size:13px; }
      .aagmg-input::placeholder { color:#888; }
      .aagmg-input.aagmg-drop { border-color:#ffaa00; box-shadow:0 0 6px rgba(255,170,0,0.4); }
      .aagmg-send { display:block; width:100%; box-sizing:border-box; padding:9px 0;
                  background:#00ffcc; color:#0a0a0a; border:none; border-radius:4px;
                  cursor:pointer; font-weight:600; font-size:14px; }
      .aagmg-send:hover { background:#33ffd6; }
      .aagmg-rollback { align-self:stretch; max-width:100%; background:#241f12;
                     border:1px solid #ffaa00; border-radius:6px; padding:8px; }
      .aagmg-cf-h { color:#ffaa00; font-weight:600; font-size:12px; margin-bottom:4px; }
      .aagmg-cf-sum { font-size:13px; margin-bottom:6px; white-space:pre-wrap; }
      .aagmg-cf-row { display:flex; gap:8px; margin-top:8px; }
      .aagmg-cf-btn { flex:1; padding:7px 0; border:none; border-radius:4px;
                    cursor:pointer; font-weight:600; }
      .aagmg-cf-action { background:#00ffcc; color:#0a0a0a; }
      .aagmg-cf-action:hover { background:#33ffd6; }
      .aagmg-cf-action:disabled { opacity:0.5; cursor:default; }
      .aagmg-rp-cap { font-size:11px; opacity:0.75; margin-bottom:4px; }
      .aagmg-rp-docs { font-size:11px; opacity:0.85; }
      .aagmg-rp-docs summary { cursor:pointer; }
      .aagmg-rp-docs ul { margin:2px 0 0 16px; padding:0; }
      .aagmg-rp-done { font-size:12px; color:#ffaa00; margin-top:6px; }
    `;
    document.head.appendChild(s);
  }

  const api = game.modules.get(MODULE_ID)?.api;
  if (!api || typeof api.isConnected !== 'function' || !api.isConnected()) { /* no live api shows dialog, exits */
    new Dialog({
      title: L('Title'),
      content: `<div class="forge-dialog-dark"><p class="warning">${L('NotConnected')}</p></div>`,
      buttons: { ok: { label: L('Close') } },
      default: 'ok',
    }).render(true);
    return;
  }

  const content = `
    <div class="forge-dialog-dark aagmg-wrap" data-aagmg="wrap">
      <div class="aagmg-status warn" data-aagmg="status">${L('StatusNoListener')}</div>
      <div class="aagmg-tabs" data-aagmg="tabs"${TABS_ON ? '' : ' style="display:none"'}></div>
      <div class="aagmg-logs" data-aagmg="logs"></div>
      <textarea class="aagmg-input" data-aagmg="input" placeholder="${L('Placeholder')}"></textarea>
      <button type="button" class="aagmg-send" data-aagmg="send">${L('Send')}</button>
    </div>`;

  let root = null;
  const $el = (k) => root?.querySelector(`[data-aagmg="${k}"]`);
  const tabs = new Map();
  let activeId = null;
  const newId = () => 't-' + Math.random().toString(16).slice(2, 10).padEnd(8, '0');
  const logFor = (tabId) => (TABS_ON && tabs.get(tabId)?.log) || tabs.get(activeId)?.log || null;

  const renderBar = () => {
    const bar = $el('tabs');
    if (!bar) return; /* no bar returns, else rebuilds */
    bar.textContent = '';
    for (const tab of tabs.values()) { /* each tab button built, ends after last */
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'aagmg-tab aagmg-' + tab.state + (tab.id === activeId ? ' aagmg-active' : '');
      button.dataset.tab = tab.id;
      const title = document.createElement('span');
      title.className = 'aagmg-tab-t';
      title.textContent = tab.title;
      title.title = tab.title;
      button.appendChild(title);
      const close = document.createElement('span');
      close.className = 'aagmg-tab-x';
      close.dataset.close = tab.id;
      close.textContent = '×';
      close.title = L('TabClose');
      button.appendChild(close);
      bar.appendChild(button);
    }
    const add = document.createElement('button');
    add.type = 'button';
    add.className = 'aagmg-tab-add';
    add.dataset.aagmg = 'tabadd';
    add.textContent = '+';
    add.title = L('TabAdd');
    add.disabled = tabs.size >= TAB_MAX;
    bar.appendChild(add);
  };

  const activate = (id) => {
    if (!tabs.has(id)) return; /* unknown id returns, else activates */
    activeId = id;
    for (const tab of tabs.values()) tab.log.hidden = tab.id !== id; /* each log hidden unless active */
    renderBar();
    const log = tabs.get(id).log;
    log.scrollTop = log.scrollHeight;
  };

  const mintTab = (id, title, state = 'idle') => {
    const log = document.createElement('div');
    log.className = 'aagmg-log';
    log.hidden = true;
    $el('logs')?.appendChild(log);
    const tab = { id, title, state, log, sent: false };
    tabs.set(id, tab);
    return tab;
  };

  const addTab = () => {
    if (tabs.size >= TAB_MAX) return null; /* at tab cap returns null */
    const tab = mintTab(TABS_ON ? newId() : MAIN_TAB, L('TabNew'));
    activate(tab.id);
    setTimeout(() => $el('input')?.focus(), 0);
    return tab;
  };

  const closeTab = (id) => {
    const tab = tabs.get(id);
    if (!tab) return; /* unknown tab returns, else continues */
    if (tab.sent) { /* sent tab notifies relay first */
      let delivered = false;
      try { delivered = !!api.closeTab(id); } catch {}
      if (!delivered) { addMsg('sys', L('StatusDisconnected'), id); setStatus('disconnected'); return; } /* undelivered reports and returns */
    }
    tabs.delete(id);
    tab.log.remove();
    if (activeId === id) { /* active tab closed activates another */
      const next = tabs.keys().next().value;
      if (next) activate(next); else addTab(); /* next tab exists activates, else adds */
    } else renderBar(); /* inactive tab closed redraws bar */
  };

  const addMsg = (role, text, tabId) => {
    const log = logFor(tabId);
    if (!log) return; /* no log returns, else appends */
    const msg = document.createElement('div');
    msg.className = 'aagmg-msg aagmg-' + role;
    if (role === 'user' || role === 'assistant') { /* user or assistant gets name label */
      const who = document.createElement('span');
      who.className = 'aagmg-who';
      who.textContent = role === 'user' ? L('You') : L('Assistant');
      msg.appendChild(who);
    }
    const body = document.createElement('span');
    body.textContent = text; /* textContent blocks HTML injection */
    msg.appendChild(body);
    log.appendChild(msg);
    log.scrollTop = log.scrollHeight;
  };

  let sessionMode = 'internal', lastState = 'no-listener';
  const setStatus = (state, text) => {
    const bar = $el('status');
    if (!bar) return; /* no status bar returns */
    lastState = state || lastState;
    const ready = lastState === 'ready' || lastState === 'working';
    const modeBit = sessionMode === 'external' ? L('ModeExternal') : L('ModeInternal');
    bar.className = 'aagmg-status ' + (ready ? 'ready' : 'warn');
    bar.textContent = modeBit + ' ' + (text || (lastState === 'working' ? L('StatusWorking')
      : ready ? L('StatusReady')
      : lastState === 'disconnected' ? L('StatusDisconnected')
      : L('StatusNoListener'))); /* working, ready, disconnected, else no listener */
  };

  const div = (cls, text) => { const d = document.createElement('div'); d.className = cls; d.textContent = text; return d; };
  const rpCard = (id) => [...(root?.querySelectorAll('[data-rollback]') || [])].find((c) => c.dataset.rollback === id);

  const markRolled = (card, state) => {
    card.querySelector('.aagmg-cf-action')?.remove();
    card.querySelector('.aagmg-rp-done')?.remove();
    card.appendChild(div('aagmg-rp-done', state === 'partial' ? L('RollbackPartial') : L('RollbackApplied')));
  };

  const renderPoint = (pt) => {
    if (!pt?.id || rpCard(pt.id)) return; /* missing id or known card exits */
    const log = logFor(pt.tabId);
    if (!log) return; /* no log returns, else builds card */
    const card = document.createElement('div');
    card.className = 'aagmg-msg aagmg-rollback';
    card.dataset.rollback = pt.id;
    card.appendChild(div('aagmg-cf-h', `${L('RollbackPoint')} ${pt.id} (${pt.kind || 'eval'})`));
    card.appendChild(div('aagmg-cf-sum', pt.summary || 'Write'));
    if (pt.captured) card.appendChild(div('aagmg-rp-cap', pt.captured)); /* captured text adds line */
    const docs = Array.isArray(pt.docs) ? pt.docs : [];
    if (docs.length) { /* docs listed builds details */
      const det = document.createElement('details');
      det.className = 'aagmg-rp-docs';
      const sm = document.createElement('summary');
      sm.textContent = docs[0] + (docs.length > 1 ? ` (+${docs.length - 1})` : '');
      det.appendChild(sm);
      const ul = document.createElement('ul');
      for (const d of docs) { const li = document.createElement('li'); li.textContent = d; ul.appendChild(li); } /* each doc listed, ends after last */
      det.appendChild(ul);
      card.appendChild(det);
    }
    if (!pt.state || pt.state === 'live') { /* live point gets button, else marked */
      const action = document.createElement('button');
      action.type = 'button';
      action.className = 'aagmg-cf-btn aagmg-cf-action';
      action.textContent = L('RollbackAction');
      action.addEventListener('click', () => {
        const prompt = `/rollback ${pt.id}`;
        const promptId = api.sendPrompt(prompt, pt.tabId);
        if (!promptId) { addMsg('sys', L('StatusDisconnected'), pt.tabId); return; } /* send failure reports and returns */
        addMsg('user', prompt, pt.tabId);
        action.disabled = true;
      });
      card.appendChild(action);
    } else markRolled(card, pt.state); /* rolled point marked, no button */
    log.appendChild(card);
    log.scrollTop = log.scrollHeight;
  };

  const renderRollback = (p) => {
    if (!p) return; /* no payload returns */
    if (p.event === 'point') renderPoint(p.point); /* point event renders card */
    else if (p.event === 'sync') for (const pt of p.points || []) renderPoint(pt); /* sync event renders each point */
    else if (p.event === 'rolled-back' && p.point?.id) { /* rolled event marks card */
      const card = rpCard(p.point.id);
      if (card) markRolled(card, p.point.state); /* card found marked rolled */
      addMsg('sys', `${p.point.id}: ${p.point.state === 'partial' ? L('RollbackPartial') : L('RollbackApplied')}`, p.point.tabId);
    }
  };

  const syncTabs = (list) => {
    if (!Array.isArray(list)) return; /* non array returns, else syncs */
    const seen = new Set();
    for (const record of list) { /* each record synced, ends after last */
      if (!record?.id || (!TABS_ON && record.id !== MAIN_TAB)) continue; /* invalid or foreign record skipped */
      seen.add(record.id);
      let tab = tabs.get(record.id);
      if (!tab) { /* new record mints tab */
        tab = mintTab(record.id, record.title || record.id, record.state);
        for (const line of record.transcript || []) addMsg(line.role, line.text, record.id); /* each transcript line replayed */
      }
      tab.title = record.title || tab.title;
      tab.state = record.state || 'idle';
      tab.sent = true;
    }
    for (const tab of [...tabs.values()]) { /* each local tab checked, ends after last */
      if (seen.has(tab.id)) continue; /* listed tab kept */
      const pristine = !tab.sent && !tab.log.childElementCount;
      if (tab.sent || (pristine && seen.size)) { tabs.delete(tab.id); tab.log.remove(); } /* stale or empty tab removed */
    }
    if (!tabs.size) addTab(); /* no tabs adds one */
    else if (!tabs.has(activeId)) activate(tabs.keys().next().value); /* active tab gone activates first */
    else renderBar(); /* otherwise redraws bar */
  };

  /* Insert dropped document references. */
  const insertRef = (ta, ref) => {
    const start = ta.selectionStart ?? ta.value.length;
    const end = ta.selectionEnd ?? start;
    const before = ta.value.slice(0, start);
    const pad = before && !/\s$/.test(before) ? ' ' : '';
    ta.value = before + pad + ref + ' ' + ta.value.slice(end);
    ta.selectionStart = ta.selectionEnd = (before + pad + ref + ' ').length;
    ta.focus();
  };

  const onDrop = (ev) => {
    let data = null;
    try { data = TextEditor.getDragEventData(ev); } catch { return; }
    if (!data?.uuid) return; /* no uuid returns, else inserts */
    ev.preventDefault();
    const ta = $el('input');
    if (!ta) return; /* no input returns */
    let name = null;
    try { name = fromUuidSync(data.uuid)?.name || null; } catch {}
    insertRef(ta, name ? `@UUID[${data.uuid}]{${name}}` : `@UUID[${data.uuid}]`);
  };

  const submit = () => {
    const ta = $el('input');
    const text = (ta?.value || '').trim();
    const tab = tabs.get(activeId);
    if (!text || !tab) return; /* empty text or tab returns */
    if (TABS_ON && text.toLowerCase() === '/close') { ta.value = ''; closeTab(tab.id); return; } /* close command closes tab and returns */
    const id = api.sendPrompt(text, tab.id);
    if (!id) { addMsg('sys', L('StatusDisconnected'), tab.id); setStatus('disconnected'); return; } /* send failure reports and returns */
    if (tab.state === 'working') addMsg('sys', L('Interrupt'), tab.id); /* busy tab logs interrupt note */
    if (!tab.sent) { tab.title = text.slice(0, TAB_TITLE_LEN); tab.state = 'working'; } /* first send titles tab */
    tab.sent = true;
    addMsg('user', text, tab.id);
    renderBar();
    ta.value = '';
    ta.focus();
  };

  /* Subscribe until the dialog closes. */
  const unsubReply = api.onReply((p) => addMsg('assistant', p?.text ?? '', p?.tabId));
  const unsubStatus = api.onStatus((p) => {
    if (p?.mode === 'external' || p?.mode === 'internal') sessionMode = p.mode; /* valid mode updates sessionMode */
    setStatus(p?.state || 'no-listener', p?.text);
  });
  const unsubTabs = api.onTabs?.((p) => syncTabs(p?.tabs));
  const unsubMode = api.onMode?.((p) => {
    sessionMode = p?.mode === 'external' ? 'external' : 'internal';
    setStatus(lastState);
  });
  const unsubRollback = api.onRollback?.((p) => renderRollback(p || {}));
  let poll = null, wasConnected = true;

  const dlg = new Dialog({
    title: L('Title'),
    content,
    buttons: { close: { label: L('Close') } },
    default: 'close',
    render: (html) => {
      root = (html && html[0]) ? html[0] : html;
      $el('send')?.addEventListener('click', submit);
      const ta = $el('input');
      ta?.addEventListener('keydown', (ev) => {
        if (ev.key === 'Enter' && !ev.shiftKey) { ev.preventDefault(); submit(); } /* plain Enter submits, Shift newline */
      });
      $el('tabs')?.addEventListener('click', (ev) => {
        const close = ev.target.closest?.('[data-close]');
        if (close) { ev.stopPropagation(); closeTab(close.dataset.close); return; } /* close click closes tab, returns */
        if (ev.target.closest?.('[data-aagmg="tabadd"]')) { addTab(); return; } /* add click adds tab, returns */
        const tab = ev.target.closest?.('[data-tab]');
        if (tab) activate(tab.dataset.tab); /* tab click activates it */
      });
      if (TABS_ON) addTab(); else activate(mintTab(MAIN_TAB, L('Title')).id); /* tabs on adds tab, else main tab */
      const wrap = $el('wrap');
      let dragDepth = 0;
      const undrop = () => { dragDepth = 0; $el('input')?.classList.remove('aagmg-drop'); };
      wrap?.addEventListener('dragenter', (ev) => {
        ev.preventDefault();
        dragDepth++;
        $el('input')?.classList.add('aagmg-drop');
      });
      wrap?.addEventListener('dragleave', () => {
        dragDepth--;
        if (dragDepth <= 0) undrop(); /* depth exhausted clears highlight */
      });
      wrap?.addEventListener('dragover', (ev) => ev.preventDefault());
      wrap?.addEventListener('drop', (ev) => {
        undrop();
        onDrop(ev);
      });
      setStatus(api.isConnected() ? 'no-listener' : 'disconnected');
      api.requestStatus();
      poll = setInterval(() => {
        const c = api.isConnected();
        if (!c) setStatus('disconnected'); /* no socket marks status disconnected */
        else if (!wasConnected) { api.requestStatus(); } /* reconnect refreshes status */
        wasConnected = c;
      }, 3000);
      setTimeout(() => $el('input')?.focus(), 50);
    },
    close: () => {
      try { unsubReply?.(); } catch {}
      try { unsubStatus?.(); } catch {}
      try { unsubTabs?.(); } catch {}
      try { unsubMode?.(); } catch {}
      try { unsubRollback?.(); } catch {}
      if (poll) { clearInterval(poll); poll = null; } /* poll running cleared, else skipped */
    },
  }, { width: 560, resizable: false, classes: ['aagmg-dialog'] });

  dlg.render(true);
}

export const CHAT_MACRO_COMMAND =
  `(${chatBoxMain.toString()})().catch((e) => console.error('[aagm-g] chat macro error:', e));`;
