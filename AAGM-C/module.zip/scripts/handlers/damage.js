// Damage primitive: plan, then atomic commit.

async function resolveTarget(ref) {
  const s = String(ref ?? '').trim();
  if (!s) return null; // blank ref returns null
  // UUID-ish (Actor.* / Token.* / Scene.x.Token.y / Compendium.*)
  if (s.includes('.')) { // dotted ref tries UUID first
    try {
      let d = await fromUuid(s);
      if (d && d.documentName === 'Token') d = d.actor; // token swaps to its actor
      if (d && d.documentName === 'Actor') return d; // actor returned, else name lookup
    } catch { /* fall through to name resolution */ }
  }
  const exact = game.actors.getName(s);
  if (exact) return exact; // exact name hit returns
  const low = s.toLowerCase();
  const ci = game.actors.find((a) => a.name.toLowerCase() === low);
  if (ci) return ci; // case insensitive hit returns
  const partial = game.actors.filter((a) => a.name.toLowerCase().includes(low));
  return partial.length === 1 ? partial[0] : null; // no match or several return null
}

function hpOf(actor) {
  const hp = actor.system?.attributes?.hp || {};
  return { value: Number(hp.value ?? 0), temp: Number(hp.temp ?? 0) };
}

function project({ value, temp }, amount) {
  const absorbed = Math.min(Math.max(temp, 0), amount);
  const after = value - (amount - absorbed);
  return { after, newTemp: Math.max(0, temp - absorbed) };
}

export async function handleDamage({ targets, amount, commit } = {}) {
  if (!Array.isArray(targets) || targets.length === 0) { // bad targets throw, valid continues
    const e = new Error('damage: `targets` must be a non-empty array'); e.code = -32602; throw e;
  }
  const amt = Number(amount);
  if (!Number.isInteger(amt) || amt <= 0) { // bad amount throws, valid continues
    const e = new Error('damage: `amount` must be a positive integer'); e.code = -32602; throw e;
  }

  const resolved = [];
  for (const ref of targets) resolved.push({ ref, actor: await resolveTarget(ref) }); // each ref resolved in order
  const missing = resolved.filter((r) => !r.actor).map((r) => r.ref);
  if (missing.length) { // unresolved refs return error
    return { error: `Could not resolve target(s): ${missing.join(', ')}. Use exact names or UUIDs.` };
  }

  const preview = resolved.map(({ actor }) => {
    const hp = hpOf(actor);
    const { after } = project(hp, amt);
    return { name: actor.name, uuid: actor.uuid, before: hp.value, temp: hp.temp, after, lethal: after < 1 };
  });
  const lethal = preview.some((p) => p.lethal);

  if (!commit) { // dry run returns preview only
    return { committed: false, lethal, amount: amt, preview };
  }

  // Re-read live HP, then write all
  const writes = [];
  for (const { actor } of resolved) { // each actor HP re-read
    const hp = hpOf(actor);
    const { after, newTemp } = project(hp, amt);
    writes.push({ actor, after, newTemp });
  }
  const applied = [];
  for (const w of writes) { // each write applied in order
    await w.actor.update({ 'system.attributes.hp.value': w.after, 'system.attributes.hp.temp': w.newTemp });
    applied.push({ name: w.actor.name, hp: w.after });
  }
  return { committed: true, amount: amt, applied };
}
