// Chat box macro source, serialized by bridge.js.

async function chatBoxMain() {
  const MODULE_ID = 'foundry-bridge';
  const STYLE_ID = 'ccc-claude-code-chat-theme';
  const LAYOUT_ID = 'ccc-claude-code-chat-layout';
  const L = (k) => game.i18n.localize('FOUNDRY_BRIDGE.CHAT.' + k);
  /* §14: tab bar shows only with multitasking on */
  const TABS_ON = !!game.settings.get(MODULE_ID, 'multitasking');
  const TAB_MAX = 5; /* tab cap for legibility */
  const TAB_TITLE_LEN = 24;
  const MAIN_TAB = 't-main'; /* lone tab when off */

  /* Prefers VTT Macro Styles journal, else inline CSS */
  async function injectMacroStyles(styleId, pageName, fallbackCSS) {
    if (document.getElementById(styleId)) return; /* styled already returns */
    let css = fallbackCSS || '';
    try {
      const journal = game.journal.getName('VTT Macro Styles');
      const page = journal?.pages?.getName(pageName);
      if (page) { /* journal page overrides fallback */
        const div = document.createElement('div');
        div.innerHTML = page.text?.content || '';
        const raw = div.textContent?.trim();
        if (raw) css = raw; /* nonblank text replaces css */
      }
    } catch (e) { /* fallback silently takes over */ }
    if (!css) return; /* no css returns, else injects */
    const style = document.createElement('style');
    style.id = styleId;
    style.textContent = css;
    document.head.appendChild(style);
  }

  /* Dark Theme fallback if the journal is gone. */
  const FALLBACK_CSS = `
    .forge-dialog-dark { background:#1a1a1a; color:#e0e0e0; }
    .forge-dialog-dark .section { background:#2a2a2a; border:1px solid #00ffcc; padding:8px; border-radius:4px; }
    .forge-dialog-dark label, .forge-dialog-dark .section-title { color:#00ffcc; }
    .forge-dialog-dark .warning { color:#ffaa00; }
  `;

  await injectMacroStyles(STYLE_ID, 'Dark Theme', FALLBACK_CSS);

  /* Chat-only layout, ccc- prefixed, out of shared theme. */
  /* Typed text forced pure white (DatJavaClass's instruction). */
  if (!document.getElementById(LAYOUT_ID)) { /* layout injected once */
    const s = document.createElement('style');
    s.id = LAYOUT_ID;
    /* Explicit heights; flex:1 collapses in Foundry Dialogs. */
    s.textContent = `
      .ccc-wrap { display:flex; flex-direction:column; gap:8px; }
      .ccc-status { font-size:12px; padding:5px 8px; border-radius:3px; border:1px solid #00ffcc; }
      .ccc-status.ready { color:#00ffcc; border-color:#00ffcc; }
      .ccc-status.warn  { color:#ffaa00; border-color:#ffaa00; }
      .ccc-tabs { display:flex; align-items:flex-end; gap:4px; margin-bottom:-8px; }
      /* width/height/line-height explicit: Foundry gives every button width:100% */
      .ccc-tab { width:auto; height:auto; line-height:1.2; flex:0 1 auto; min-width:0; max-width:150px;
                 display:flex; align-items:center; gap:6px; padding:4px 8px; background:#222;
                 border:1px solid #444; border-bottom:none; border-radius:4px 4px 0 0; color:#bbb;
                 cursor:pointer; font-size:12px; }
      .ccc-tab::before { content:''; width:7px; height:7px; border-radius:50%; background:#555; flex:none; }
      .ccc-tab.ccc-active { background:#2a2a2a; border-color:#00ffcc; color:#e0e0e0; }
      .ccc-tab.ccc-working::before { background:#00ffcc; }
      .ccc-tab.ccc-done::before { background:#3a7; }
      .ccc-tab.ccc-gated { border-color:#ffaa00; animation:ccc-pulse 1s ease-in-out infinite; }
      .ccc-tab.ccc-gated::before { background:#ffaa00; }
      @keyframes ccc-pulse { 0%,100% { background:#241f12; } 50% { background:#5a4410; } }
      .ccc-tab-t { flex:1 1 auto; min-width:0; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
      .ccc-tab-x { opacity:0.6; padding:0 2px; flex:none; }
      .ccc-tab-x:hover { opacity:1; color:#ff6666; }
      .ccc-tab-add { width:auto; height:auto; line-height:1.2; flex:none; padding:4px 9px; background:#222;
                     border:1px solid #444; border-bottom:none; border-radius:4px 4px 0 0; color:#00ffcc;
                     cursor:pointer; font-weight:600; }
      .ccc-tab-add:disabled { opacity:0.35; cursor:default; }
      .ccc-log { height:320px; width:100%; box-sizing:border-box; overflow-y:auto;
                 background:#141414; border:1px solid #333; border-radius:4px; padding:8px;
                 display:flex; flex-direction:column; gap:6px; }
      .ccc-log[hidden] { display:none; }
      .ccc-msg { white-space:pre-wrap; word-break:break-word; padding:6px 8px;
                 border-radius:6px; font-size:13px; line-height:1.4; }
      .ccc-msg .ccc-who { display:block; font-size:11px; opacity:0.75; margin-bottom:2px; }
      .ccc-user   { background:#22323a; border-left:3px solid #00ffcc; align-self:flex-end; max-width:85%; }
      .ccc-claude { background:#2a2a2a; border-left:3px solid #ffaa00; align-self:flex-start; max-width:85%; }
      .ccc-sys    { color:#ffaa00; font-size:12px; align-self:center; }
      .ccc-input { display:block; width:100% !important; box-sizing:border-box !important;
                   height:96px; resize:vertical; color:#fff !important; background:#101010;
                   border:1px solid #00ffcc; border-radius:4px; padding:8px;
                   font-family:inherit; font-size:13px; }
      .ccc-input::placeholder { color:#888; }
      .ccc-input.ccc-drop { border-color:#ffaa00; box-shadow:0 0 6px rgba(255,170,0,0.4); }
      .ccc-send { display:block; width:100%; box-sizing:border-box; padding:9px 0;
                  background:#00ffcc; color:#0a0a0a; border:none; border-radius:4px;
                  cursor:pointer; font-weight:600; font-size:14px; }
      .ccc-send:hover { background:#33ffd6; }
      .ccc-confirm { align-self:stretch; max-width:100%; background:#241f12;
                     border:1px solid #ffaa00; border-radius:6px; padding:8px; }
      .ccc-confirm.ccc-double { border-color:#ff6666; background:#2a1414; }
      .ccc-cf-h { color:#ffaa00; font-weight:600; font-size:12px; margin-bottom:4px; }
      .ccc-confirm.ccc-double .ccc-cf-h { color:#ff6666; }
      .ccc-cf-sum { font-size:13px; margin-bottom:6px; white-space:pre-wrap; }
      .ccc-cf-code { max-height:160px; overflow:auto; background:#0c0c0c;
                     border:1px solid #333; border-radius:4px; padding:6px;
                     font-family:monospace; font-size:12px; white-space:pre; color:#cfe; }
      .ccc-cf-tbl { width:100%; font-size:12px; border-collapse:collapse; margin-top:4px; }
      .ccc-cf-tbl td, .ccc-cf-tbl th { border-bottom:1px solid #333; padding:2px 6px; text-align:left; }
      .ccc-cf-row { display:flex; gap:8px; margin-top:8px; }
      .ccc-cf-btn { flex:1; padding:7px 0; border:none; border-radius:4px;
                    cursor:pointer; font-weight:600; }
      .ccc-cf-approve { background:#00ffcc; color:#0a0a0a; }
      .ccc-cf-approve:hover { background:#33ffd6; }
      .ccc-cf-deny { background:#552222; color:#ffdddd; }
      .ccc-cf-deny:hover { background:#773333; }
      .ccc-cf-done { font-size:12px; margin-top:6px; opacity:0.85; }
      .ccc-user.ccc-int { border-left:3px solid #ffaa00; }
      .ccc-confirm.ccc-rp { border-color:#2aa9c4; background:#122229; }
      .ccc-rp .ccc-cf-h { color:#5fd4ea; }
      .ccc-rp-cap { font-size:11px; opacity:0.75; margin-bottom:4px; }
      .ccc-rp-docs { font-size:11px; opacity:0.85; }
      .ccc-rp-docs summary { cursor:pointer; }
      .ccc-rp-docs ul { margin:2px 0 0 16px; padding:0; }
      .ccc-rp-btn { background:#2aa9c4; color:#0a0a0a; }
      .ccc-rp-btn:hover { background:#5fd4ea; }
      .ccc-rp-btn:disabled { opacity:0.5; cursor:default; }
      .ccc-confirm.ccc-rp.ccc-rp-done { border-color:#2a4a52; background:#161c1e; opacity:0.8; }
    `;
    document.head.appendChild(s);
  }

  const api = game.modules.get(MODULE_ID)?.api;
  if (!api || typeof api.isConnected !== 'function' || !api.isConnected()) { /* no live bridge shows dialog, exits */
    new Dialog({
      title: L('Title'),
      content: `<div class="forge-dialog-dark"><p class="warning">${L('NotConnected')}</p></div>`,
      buttons: { ok: { label: L('Close') } },
      default: 'ok',
    }).render(true);
    return;
  }

  const content = `
    <div class="forge-dialog-dark ccc-wrap" data-ccc="wrap">
      <div class="ccc-status warn" data-ccc="status">${L('StatusNoListener')}</div>
      <div class="ccc-tabs" data-ccc="tabs"${TABS_ON ? '' : ' style="display:none"'}></div>
      <div class="ccc-logs" data-ccc="logs"></div>
      <textarea class="ccc-input" data-ccc="input" placeholder="${L('Placeholder')}"></textarea>
      <button type="button" class="ccc-send" data-ccc="send">${L('Send')}</button>
    </div>`;

  let root = null;
  const $el = (k) => root?.querySelector(`[data-ccc="${k}"]`);

  /* §14 tab table: relay owns truth, box resyncs */
  const tabs = new Map(); /* tab records by id */
  let activeId = null;
  const newId = () => 't-' + Math.random().toString(16).slice(2, 10).padEnd(8, '0');
  const logFor = (tabId) => (TABS_ON && tabs.get(tabId)?.log) || tabs.get(activeId)?.log || null;

  const renderBar = () => {
    const bar = $el('tabs');
    if (!bar) return; /* no bar returns */
    bar.textContent = '';
    for (const t of tabs.values()) { /* one button per tab */
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'ccc-tab ccc-' + (t.state || 'idle') + (t.id === activeId ? ' ccc-active' : '');
      b.dataset.tab = t.id;
      const title = document.createElement('span');
      title.className = 'ccc-tab-t';
      title.textContent = t.title;
      title.title = t.title;
      b.appendChild(title);
      const x = document.createElement('span');
      x.className = 'ccc-tab-x';
      x.dataset.close = t.id;
      x.textContent = '×';
      x.title = L('TabClose');
      b.appendChild(x);
      bar.appendChild(b);
    }
    const add = document.createElement('button');
    add.type = 'button';
    add.className = 'ccc-tab-add';
    add.dataset.ccc = 'tabadd';
    add.textContent = '+';
    add.title = L('TabAdd');
    add.disabled = tabs.size >= TAB_MAX;
    bar.appendChild(add);
  };

  const activate = (id) => {
    if (!tabs.has(id)) return; /* unknown id returns */
    activeId = id;
    for (const t of tabs.values()) t.log.hidden = t.id !== id; /* only chosen log shown */
    renderBar();
    const log = tabs.get(id).log;
    log.scrollTop = log.scrollHeight;
  };

  const mintTab = (id, title, state) => {
    const log = document.createElement('div');
    log.className = 'ccc-log';
    log.hidden = true;
    $el('logs')?.appendChild(log);
    const t = { id, title, state: state || 'idle', log, sent: false };
    tabs.set(id, t);
    return t;
  };

  const addTab = () => {
    if (tabs.size >= TAB_MAX) return null; /* at cap returns null */
    const t = mintTab(newId(), L('TabNew'), 'idle');
    activate(t.id);
    setTimeout(() => $el('input')?.focus(), 0);
    return t;
  };

  const closeTab = (id) => {
    const t = tabs.get(id);
    if (!t) return; /* unknown tab returns */
    tabs.delete(id);
    t.log.remove();
    if (t.sent) { try { api.closeTab(id); } catch (e) {} } /* sent tab closes on relay, pristine skips */
    if (activeId === id) { /* closed active tab picks neighbor */
      const next = tabs.keys().next().value;
      if (next) activate(next); else addTab(); /* next tab or fresh tab */
    } else renderBar(); /* inactive close just redraws */
  };

  const addMsg = (role, text, tabId, intr) => {
    const log = logFor(tabId);
    if (!log) return; /* no log returns */
    const msg = document.createElement('div');
    msg.className = 'ccc-msg ccc-' + role + (intr ? ' ccc-int' : '');
    if (role === 'user' || role === 'claude') { /* speaker label for user, claude */
      const who = document.createElement('span');
      who.className = 'ccc-who';
      who.textContent = role === 'user' ? L('You') : L('Claude');
      if (intr) who.textContent = '⚡ ' + who.textContent + ' (' + L('Interrupt') + ')'; /* interrupt marks label */
      msg.appendChild(who);
    }
    const body = document.createElement('span');
    body.textContent = text; /* no HTML injection, CSS keeps newlines */
    msg.appendChild(body);
    log.appendChild(msg);
    log.scrollTop = log.scrollHeight;
  };

  /* New ids rebuild from transcript, known ids resync */
  const syncTabs = (list) => {
    if (!Array.isArray(list)) return; /* bad list returns */
    const seen = new Set();
    for (const r of list) { /* each relay tab merged */
      if (!r?.id || (!TABS_ON && r.id !== MAIN_TAB)) continue; /* idless or hidden tab skipped */
      seen.add(r.id);
      let t = tabs.get(r.id);
      if (!t) { /* new id mints tab, replays transcript */
        t = mintTab(r.id, r.title || r.id, r.state);
        for (const line of r.transcript || []) addMsg(line.role, line.text, r.id); /* each transcript line added */
      }
      t.title = r.title || t.title;
      t.state = r.state || 'idle';
      t.sent = true;
    }
    for (const t of [...tabs.values()]) { /* each local tab checked */
      if (seen.has(t.id)) continue; /* relay listed tab kept */
      const pristine = !t.sent && !t.log.childElementCount;
      if (t.sent || (pristine && seen.size)) { tabs.delete(t.id); t.log.remove(); } /* stale tab removed */
    }
    if (!tabs.size) addTab(); /* empty table gets new tab */
    else if (!tabs.has(activeId)) activate(tabs.keys().next().value); /* lost active picks first */
    else renderBar(); /* unchanged active redraws */
  };

  const setStatus = (state) => {
    const bar = $el('status');
    if (!bar) return; /* no bar returns */
    const ready = state === 'ready';
    bar.className = 'ccc-status ' + (ready ? 'ready' : 'warn');
    bar.textContent = ready ? L('StatusReady') /* ready, disconnected, ext, else no listener */
      : state === 'disconnected' ? L('StatusDisconnected')
      : state === 'ext' ? L('StatusExt')
      : L('StatusNoListener');
  };

  /* §9 gate card: double level needs second approval */
  const renderConfirm = (p) => {
    const log = logFor(p?.tabId);
    if (!log || !p || !p.opId) return; /* bad card data returns */
    if (log.querySelector(`[data-op="${p.opId}"]`)) return; /* card exists returns, hello re-sends */
    const card = document.createElement('div');
    card.className = 'ccc-msg ccc-confirm' + (p.level === 'double' ? ' ccc-double' : '');
    card.dataset.op = p.opId;

    const h = document.createElement('div');
    h.className = 'ccc-cf-h';
    h.textContent = (p.level === 'double' ? L('ConfirmDestructive') : L('ConfirmWrite')) + ' - ' + (p.kind || 'op');
    card.appendChild(h);

    const sum = document.createElement('div');
    sum.className = 'ccc-cf-sum';
    sum.textContent = p.summary || '(no summary provided)';
    card.appendChild(sum);

    if (p.code) { /* code block shown when given */
      const pre = document.createElement('pre');
      pre.className = 'ccc-cf-code';
      pre.textContent = p.code;
      card.appendChild(pre);
    }
    if (Array.isArray(p.preview) && p.preview.length) { /* preview table when rows given */
      const tbl = document.createElement('table');
      tbl.className = 'ccc-cf-tbl';
      const hr = document.createElement('tr');
      ['Target', 'HP', '→'].forEach((c) => { const th = document.createElement('th'); th.textContent = c; hr.appendChild(th); });
      tbl.appendChild(hr);
      for (const row of p.preview) { /* one table row per target */
        const tr = document.createElement('tr');
        [row.name, String(row.before), '→ ' + String(row.after)].forEach((v) => { /* each cell appended */
          const td = document.createElement('td'); td.textContent = v; tr.appendChild(td);
        });
        tbl.appendChild(tr);
      }
      card.appendChild(tbl);
    }

    let resolved = false;
    const finish = (approved, reason, msgKey) => {
      if (resolved) return; /* second click ignored */
      resolved = true;
      try { api.sendConfirmResult(p.opId, approved, reason); } catch (e) {}
      card.querySelector('.ccc-cf-row')?.remove();
      const done = document.createElement('div');
      done.className = 'ccc-cf-done';
      done.textContent = L(msgKey);
      card.appendChild(done);
      log.scrollTop = log.scrollHeight;
    };
    const buildRow = (okLabel, onOk, noLabel, onNo) => {
      const row = document.createElement('div');
      row.className = 'ccc-cf-row';
      const ok = document.createElement('button');
      ok.type = 'button'; ok.className = 'ccc-cf-btn ccc-cf-approve'; ok.textContent = okLabel;
      ok.addEventListener('click', onOk);
      const no = document.createElement('button');
      no.type = 'button'; no.className = 'ccc-cf-btn ccc-cf-deny'; no.textContent = noLabel;
      no.addEventListener('click', onNo);
      row.appendChild(ok); row.appendChild(no);
      return row;
    };

    card.appendChild(buildRow(
      L('Approve'),
      () => {
        if (p.level === 'double') { /* double level asks again */
          card.querySelector('.ccc-cf-row')?.remove();
          const warn = document.createElement('div');
          warn.className = 'ccc-cf-h';
          warn.textContent = L('ConfirmAgain');
          card.appendChild(warn);
          card.appendChild(buildRow(
            L('ApproveFinal'), () => finish(true, 'approved-double', 'Approved'),
            L('Cancel'), () => finish(false, 'cancelled', 'Denied'),
          ));
          log.scrollTop = log.scrollHeight;
        } else { /* single level approves now */
          finish(true, 'approved', 'Approved');
        }
      },
      L('Deny'),
      () => finish(false, 'denied', 'Denied'),
    ));

    log.appendChild(card);
    log.scrollTop = log.scrollHeight;
  };

  /* 2.0: writes run at once, undo via card */
  const rpCard = (id) => (id ? root?.querySelector(`[data-rp="${id}"]`) : null);
  const tabOf = (node) => [...tabs.values()].find((t) => t.log.contains(node))?.id;
  const div = (cls, text) => { const d = document.createElement('div'); d.className = cls; d.textContent = text; return d; };

  const markRolled = (card, state, via) => {
    card.querySelector('.ccc-cf-row')?.remove();
    card.querySelector('.ccc-cf-done')?.remove();
    card.classList.add('ccc-rp-done');
    card.appendChild(div('ccc-cf-done', state === 'partial' ? L('RolledBackPartial') : `${L('RolledBack')} (via ${via || 'box'})`));
  };

  const renderPoint = (pt) => {
    if (!pt?.id || rpCard(pt.id)) return; /* idless or known point returns, else renders */
    const log = logFor(pt.tabId);
    if (!log) return; /* no log returns */
    const card = document.createElement('div');
    card.className = 'ccc-msg ccc-confirm ccc-rp';
    card.dataset.rp = pt.id;
    card.appendChild(div('ccc-cf-h', `${L('RollbackPoint')} ${pt.id} (${pt.kind || 'eval'})`));
    card.appendChild(div('ccc-cf-sum', pt.summary || '(no summary provided)'));
    if (pt.captured) card.appendChild(div('ccc-rp-cap', pt.captured)); /* capture note when given */
    const docs = Array.isArray(pt.docs) ? pt.docs : [];
    if (docs.length) { /* doc list when any */
      const det = document.createElement('details');
      det.className = 'ccc-rp-docs';
      const sm = document.createElement('summary');
      sm.textContent = docs[0] + (docs.length > 1 ? ` (+${docs.length - 1})` : '');
      det.appendChild(sm);
      const ul = document.createElement('ul');
      for (const d of docs) { const li = document.createElement('li'); li.textContent = d; ul.appendChild(li); } /* one list item per doc */
      det.appendChild(ul);
      card.appendChild(det);
    }
    if (!pt.state || pt.state === 'live') { /* live point gets button, else marked */
      const row = document.createElement('div');
      row.className = 'ccc-cf-row';
      const btn = document.createElement('button');
      btn.type = 'button'; btn.className = 'ccc-cf-btn ccc-rp-btn'; btn.textContent = L('RollBack');
      btn.addEventListener('click', () => {
        btn.disabled = true; /* locked until relay replies */
        let ok = false;
        try { ok = api.rollbackTo(pt.id) !== false; } catch (e) {}
        if (!ok) { btn.disabled = false; addMsg('sys', L('StatusDisconnected'), tabOf(card)); } /* failed send re-enables button */
      });
      row.appendChild(btn);
      card.appendChild(row);
    } else markRolled(card, pt.state, pt.via); /* finished point marked rolled */
    log.appendChild(card);
    log.scrollTop = log.scrollHeight;
  };

  const onRollback = (p) => {
    if (!p) return; /* empty event returns */
    switch (p.event) { /* point, sync, rolled-back, error routed */
      case 'point': renderPoint(p.point); break;
      case 'sync': for (const pt of p.points || []) renderPoint(pt); break; /* each synced point rendered */
      case 'rolled-back': {
        const pt = p.point || {};
        const card = rpCard(pt.id);
        if (card) markRolled(card, pt.state, p.via || pt.via); /* existing card marked, else rendered */
        else renderPoint({ ...pt, state: pt.state === 'partial' ? 'partial' : 'rolled-back', via: p.via || pt.via }); /* unseen point rendered with state */
        const tab = tabOf(rpCard(pt.id)) || pt.tabId;
        addMsg('sys', `${pt.state === 'partial' ? L('RolledBackPartial') : L('RolledBack')}: ${pt.id || ''} (via ${p.via || pt.via || 'box'})`, tab);
        break;
      }
      case 'error': {
        const card = rpCard(p.pointId);
        const btn = card?.querySelector('.ccc-rp-btn');
        if (btn) btn.disabled = false; /* button re-enabled on error */
        addMsg('sys', `${L('RollbackError')} ${p.text || ''}`, card ? tabOf(card) : undefined);
        break;
      }
    }
  };

  /* Drop inserts @UUID ref, not raw JSON paste */
  const insertRef = (ta, ref) => {
    const start = ta.selectionStart ?? ta.value.length;
    const end = ta.selectionEnd ?? start;
    const before = ta.value.slice(0, start);
    const pad = before && !/\s$/.test(before) ? ' ' : '';
    ta.value = before + pad + ref + ' ' + ta.value.slice(end);
    ta.selectionStart = ta.selectionEnd = (before + pad + ref + ' ').length;
    ta.focus();
  };
  const onDrop = (ev) => {
    let data = null;
    try { data = TextEditor.getDragEventData(ev); } catch (e) { return; }
    if (!data?.uuid) return; /* non document drop returns */
    ev.preventDefault();
    const ta = $el('input');
    if (!ta) return; /* no input returns */
    let name = null;
    try { name = fromUuidSync(data.uuid)?.name || null; } catch (e) { /* uuid alone still resolves on Claude's side */ }
    insertRef(ta, name ? `@UUID[${data.uuid}]{${name}}` : `@UUID[${data.uuid}]`);
  };

  const submit = () => {
    const ta = $el('input');
    const text = (ta?.value || '').trim();
    const t = tabs.get(activeId);
    if (!text || !t) return; /* blank text or tab returns */
    if (TABS_ON && text.toLowerCase() === '/close') { ta.value = ''; closeTab(t.id); return; } /* close command acts like the x */
    const intr = (t.state === 'working' || t.state === 'gated') && !/^\/(exit|ext|int|log|rollback|points)\b/i.test(text); /* relay eats commands */
    const id = api.sendPrompt(text, t.id);
    if (!id) { addMsg('sys', L('StatusDisconnected')); setStatus('disconnected'); return; } /* failed send shows disconnect */
    if (!t.sent) { t.title = text.slice(0, TAB_TITLE_LEN); t.state = 'working'; } /* first send names tab, relay agrees */
    t.sent = true;
    addMsg('user', text, t.id, intr);
    renderBar();
    ta.value = '';
    ta.focus();
  };

  /* §13.3: one card tracks chain grant to end */
  let chainCard = null;
  const onChain = (p) => {
    const log = logFor(p?.tabId);
    if (!log || !p) return; /* bad chain event returns */
    if (p.event === 'grant') { /* grant opens progress card */
      chainCard = document.createElement('div');
      chainCard.className = 'ccc-msg ccc-confirm';
      const h = document.createElement('div');
      h.className = 'ccc-cf-h';
      h.textContent = L('ChainActive');
      chainCard.appendChild(h);
      const prog = document.createElement('div');
      prog.className = 'ccc-cf-sum';
      prog.dataset.ccc = 'chainprog';
      prog.textContent = `0/${p.count} - ${p.text || ''}`;
      chainCard.appendChild(prog);
      const cancel = document.createElement('button');
      cancel.type = 'button';
      cancel.className = 'ccc-cf-btn ccc-cf-deny';
      cancel.textContent = L('ChainCancel');
      cancel.addEventListener('click', () => { try { api.cancelChain(p.chainId); } catch (e) {} });
      chainCard.appendChild(cancel);
      log.appendChild(chainCard);
      log.scrollTop = log.scrollHeight;
    } else if (p.event === 'gate' && chainCard) { /* gate updates progress count */
      const prog = chainCard.querySelector('[data-ccc="chainprog"]');
      if (prog) prog.textContent = `${p.n}/${p.count} - ${p.text || ''}`; /* progress text updated when found */
      log.scrollTop = log.scrollHeight;
    } else if (p.event === 'end') { /* end drops cancel, logs result */
      chainCard?.querySelector('button')?.remove();
      chainCard = null;
      addMsg('sys', `${L('ChainEnded')} ${p.n}/${p.count} (${p.text || ''})`, p.tabId);
    }
  };

  /* Subscribe before dialog opens, unsubscribe on close */
  const unsubReply = api.onReply((p) => addMsg(p?.system ? 'sys' : 'claude', p?.text ?? '', p?.tabId));
  const unsubStatus = api.onStatus((p) => setStatus(p?.state || 'no-listener'));
  const unsubConfirm = api.onConfirm((p) => renderConfirm(p || {}));
  const unsubChain = api.onChain ? api.onChain(onChain) : null;
  const unsubTabs = api.onTabs ? api.onTabs((p) => syncTabs(p?.tabs)) : null;
  const unsubRollback = api.onRollback ? api.onRollback(onRollback) : null;
  let poll = null, wasConnected = true;

  const dlg = new Dialog({
    title: L('Title'),
    content,
    buttons: { close: { label: L('Close') } },
    default: 'close',
    render: (html) => {
      root = (html && html[0]) ? html[0] : html;
      $el('send')?.addEventListener('click', submit);
      const ta = $el('input');
      ta?.addEventListener('keydown', (ev) => {
        if (ev.key === 'Enter' && !ev.shiftKey) { ev.preventDefault(); submit(); } /* plain Enter submits */
      });
      /* Tab bar: one delegated listener; close beats select. */
      $el('tabs')?.addEventListener('click', (ev) => {
        const x = ev.target.closest?.('[data-close]');
        if (x) { ev.stopPropagation(); closeTab(x.dataset.close); return; } /* close icon closes tab */
        if (ev.target.closest?.('[data-ccc="tabadd"]')) { addTab(); return; } /* plus button adds tab */
        const b = ev.target.closest?.('[data-tab]');
        if (b) activate(b.dataset.tab); /* tab body selects tab */
      });
      if (TABS_ON) addTab(); else activate(mintTab(MAIN_TAB, L('Title'), 'idle').id); /* tabs on adds, off mints main */
      /* Whole box is drop zone; counter tracks bubbling */
      const wrap = $el('wrap');
      let dragDepth = 0;
      const undrop = () => { dragDepth = 0; $el('input')?.classList.remove('ccc-drop'); };
      wrap?.addEventListener('dragenter', (ev) => { ev.preventDefault(); dragDepth++; $el('input')?.classList.add('ccc-drop'); });
      wrap?.addEventListener('dragleave', () => { dragDepth--; if (dragDepth <= 0) undrop(); }); /* fully left drop zone clears */
      wrap?.addEventListener('dragover', (ev) => ev.preventDefault());
      wrap?.addEventListener('drop', (ev) => { undrop(); onDrop(ev); });
      setStatus(api.isConnected() ? 'no-listener' : 'disconnected');
      api.requestStatus(); /* relay answers: status, tab table, live cards */
      poll = setInterval(() => {
        const c = api.isConnected();
        if (!c) setStatus('disconnected'); /* dropped link shows disconnected */
        else if (!wasConnected) { api.requestStatus(); } /* reconnect refreshes status */
        wasConnected = c;
      }, 3000);
      setTimeout(() => $el('input')?.focus(), 50);
    },
    close: () => {
      try { unsubReply?.(); } catch (e) {}
      try { unsubStatus?.(); } catch (e) {}
      try { unsubConfirm?.(); } catch (e) {}
      try { unsubChain?.(); } catch (e) {}
      try { unsubTabs?.(); } catch (e) {}
      try { unsubRollback?.(); } catch (e) {}
      if (poll) { clearInterval(poll); poll = null; } /* timer cleared on close */
    },
  }, { width: 560, resizable: false, classes: ['ccc-dialog'] });

  dlg.render(true);
}

export const CHAT_MACRO_COMMAND =
  `(${chatBoxMain.toString()})().catch((e) => console.error('[foundry-bridge] chat macro error:', e));`;
